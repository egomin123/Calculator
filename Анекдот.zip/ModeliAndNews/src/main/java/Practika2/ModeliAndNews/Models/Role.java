package Practika2.ModeliAndNews.Models;


public enum Role {
    USER;
}
