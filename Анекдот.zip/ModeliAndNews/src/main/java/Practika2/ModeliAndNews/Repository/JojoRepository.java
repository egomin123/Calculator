package Practika2.ModeliAndNews.Repository;

import Practika2.ModeliAndNews.Models.onetoone.Jojo;
import org.springframework.data.repository.CrudRepository;

public interface JojoRepository extends CrudRepository<Jojo,Long> {

}

