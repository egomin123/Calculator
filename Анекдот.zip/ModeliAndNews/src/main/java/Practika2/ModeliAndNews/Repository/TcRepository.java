package Practika2.ModeliAndNews.Repository;

import Practika2.ModeliAndNews.Models.onetomany.Tc;
import org.springframework.data.repository.CrudRepository;

public interface TcRepository extends CrudRepository<Tc,Long> {

}
