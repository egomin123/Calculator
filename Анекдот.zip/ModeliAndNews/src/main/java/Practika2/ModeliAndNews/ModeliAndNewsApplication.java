package Practika2.ModeliAndNews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModeliAndNewsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModeliAndNewsApplication.class, args);
	}

}
