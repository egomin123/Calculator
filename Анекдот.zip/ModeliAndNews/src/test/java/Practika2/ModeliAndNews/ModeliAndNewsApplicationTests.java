package Practika2.ModeliAndNews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModeliAndNewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
